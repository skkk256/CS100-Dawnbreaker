#ifndef TOOLS_H__
#define TOOLS_H__
#include "GameObjects.h"

class Tools : public GameObject {

};

#endif // !TOOLS_H__

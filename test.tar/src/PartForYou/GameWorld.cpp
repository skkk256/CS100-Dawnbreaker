#include "GameWorld.h"
#include "GameObjects.h"
#include "Enemy.h"
#include "utils.h"
#include "Projectile.h"

//������
GameWorld::GameWorld() : life(3), dawnbreaker(nullptr), allowed(2) {
}

GameWorld::~GameWorld() {

}

void GameWorld::Init() {
	dawnbreaker = new Dawnbreaker(300, 100, this);
	for (int i = 1; i < 30; ++i) {
		ObjectList.push_back(new Star(randInt(0, WINDOW_WIDTH - 1), randInt(0, WINDOW_HEIGHT - 1), randInt(10, 40) / 100.0));
	}
}

LevelStatus GameWorld::Update() {
	// ���ɱ����͵л�
	if (randInt(1, 30) == 1)
		ObjectList.push_back(new Star(randInt(0, WINDOW_WIDTH - 1), WINDOW_HEIGHT, randInt(10, 40) / 100.0));
	if (allowed > 0) {
		ObjectList.push_back(
			new Omegatron(randInt(0, WINDOW_WIDTH - 1), WINDOW_HEIGHT, 20, 4, 2, dawnbreaker)
		);
		ObjectList.push_back(
			new Sigmatron(randInt(0, WINDOW_WIDTH - 1), WINDOW_HEIGHT, 20, 2, dawnbreaker)
		);
		allowed -= 1;
	}
	//�������ж����dawnbreaker
	dawnbreaker->Update();
	for (auto iter = ObjectList.begin(); iter != ObjectList.end(); iter++) {
		(*iter)->Update();
		switch ((*iter)->GetType())
		{
		case GameObject::alpha:
			if (((Enemy*)(*iter))->NeedShoot()) {
				ObjectList.push_front(
					new Projectile(IMGID_RED_BULLET, (*iter)->GetX(), (*iter)->GetY() - 50, 180, 0.5, ((Enemy*)(*iter))->GetAgreesivity(), false)
				);
				((Projectile*)(*ObjectList.begin()))->SetFlightStrategy(2);
			}
			break;
		case GameObject::sigma:
			break;
		case GameObject::omega:
			if (((Enemy*)(*iter))->NeedShoot()) {
				ObjectList.push_front(
					new Projectile(IMGID_RED_BULLET, (*iter)->GetX(), (*iter)->GetY() - 50, 162, 0.5, ((Enemy*)(*iter))->GetAgreesivity(), false)
				);
				((Projectile*)(*ObjectList.begin()))->SetFlightStrategy(1);
				ObjectList.push_front(
					new Projectile(IMGID_RED_BULLET, (*iter)->GetX(), (*iter)->GetY() - 50, 198, 0.5, ((Enemy*)(*iter))->GetAgreesivity(), false)
				);
				((Projectile*)(*ObjectList.begin()))->SetFlightStrategy(3);
			}
			break;
		}
	}
	//�ж���Ϸ�Ƿ����
	if (IsGameOver()) {
		life -= 1;
		return LevelStatus::DAWNBREAKER_DESTROYED;
	}
	//���Ӻ�ɾ������
	if (dawnbreaker->NeedShoot() == 1) {
		ObjectList.push_back(
			new Projectile(IMGID_BLUE_BULLET, dawnbreaker->GetX(), dawnbreaker->GetY() + 50, 0, 0.5 + 0.1 * dawnbreaker->GetUpgrade(), 5 + 3 * dawnbreaker->GetUpgrade(), false)
		);
	}
	for (auto iter = ObjectList.begin(); iter != ObjectList.end();) {
		if ((*iter)->JudgeDestroyed()) {
			delete* iter;
			ObjectList.erase(iter++);
		}
		else {
			++iter;
		}
	}
}

void GameWorld::CleanUp() {
	delete dawnbreaker;
	for (auto iter = ObjectList.begin(); iter != ObjectList.end();) {
		delete* iter;
		ObjectList.erase(iter++);
	}
	ObjectList.clear();
}


bool GameWorld::IsGameOver() const {
  return false;
}
